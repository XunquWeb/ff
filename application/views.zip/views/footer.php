<link href="<?php echo base_url('css/footer.css')?>" rel="stylesheet">

<div class="footer_container">
    <span>©寻趣网 2015</span>|<a href="#">了解寻趣</a>|<a href="#">加入我们</a>|<a href="#" data-toggle="modal" data-target="#feedback">建议反馈</a> 
</div>