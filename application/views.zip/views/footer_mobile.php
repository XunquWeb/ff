<head>
	<link href="<?php echo base_url('css/footer_mobile.css')?>" rel="stylesheet">
</head>

	<footer>
	    <a href="/index/newhome" class="ft_item iconfont selected"></a>
	    <a href="/project/projects?type=hot" class="ft_item iconfont"></a>
	    <a href="/publish/new" class="ft_item iconfont ft_item_btn"><i id="new_btn"></i></a>
	    <a href="/user/message" class="ft_item iconfont"><i class="unread-msg" style="display: none;"></i></a>
	    <a href="/member/index" class="ft_item iconfont"></a>
	</footer>
